--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.10
-- Dumped by pg_dump version 9.5.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.user_role DROP CONSTRAINT user_role_role_id_fkey;
ALTER TABLE ONLY public.user_role DROP CONSTRAINT user_role_auth_user_id_fkey;
ALTER TABLE ONLY public.requests DROP CONSTRAINT requests_user_auth_fkey;
ALTER TABLE ONLY public.requests DROP CONSTRAINT requests_application_master_fkey;
ALTER TABLE ONLY public.link_master DROP CONSTRAINT link_master_parent_link_id_fkey;
ALTER TABLE ONLY public.link_master DROP CONSTRAINT link_master_link_type_fkey;
ALTER TABLE ONLY public.link_master DROP CONSTRAINT link_master_application_id_fkey;
ALTER TABLE ONLY public.inventory DROP CONSTRAINT inventory_application_master_fkey;
ALTER TABLE ONLY public.application_master DROP CONSTRAINT application_master_item_type_master_fkey;
DROP TRIGGER stock_update ON public.inventory;
DROP TRIGGER add_transaction ON public.requests;
ALTER TABLE ONLY public.user_auth DROP CONSTRAINT user_auth_pkey;
ALTER TABLE ONLY public.role_master DROP CONSTRAINT role_master_pkey;
ALTER TABLE ONLY public.link_type_master DROP CONSTRAINT link_type_master_pkey;
ALTER TABLE ONLY public.link_master DROP CONSTRAINT link_mast_pkey;
ALTER TABLE ONLY public.item_type_master DROP CONSTRAINT item_type_master_pkey;
ALTER TABLE ONLY public.inventory DROP CONSTRAINT inventory_pkey;
ALTER TABLE ONLY public.user_role DROP CONSTRAINT emp_role_pkey;
ALTER TABLE ONLY public.application_master DROP CONSTRAINT application_master_application_name_key;
ALTER TABLE ONLY public.application_master DROP CONSTRAINT adm_application_pkey;
ALTER TABLE ONLY public.requests DROP CONSTRAINT "Requests_pkey";
ALTER TABLE public.user_role ALTER COLUMN role_sl_no DROP DEFAULT;
ALTER TABLE public.user_auth ALTER COLUMN user_id DROP DEFAULT;
ALTER TABLE public.role_master ALTER COLUMN role_id DROP DEFAULT;
ALTER TABLE public.requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.link_type_master ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.link_master ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inventory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.application_master ALTER COLUMN application_id DROP DEFAULT;
DROP SEQUENCE public.user_role_role_sl_no_seq;
DROP TABLE public.user_role;
DROP SEQUENCE public.user_auth_user_id_seq;
DROP TABLE public.user_auth;
DROP SEQUENCE public.role_master_role_id_seq;
DROP TABLE public.role_master;
DROP SEQUENCE public.link_type_master_id_seq;
DROP TABLE public.link_type_master;
DROP SEQUENCE public.link_master_id_seq;
DROP TABLE public.link_master;
DROP TABLE public.item_type_master;
DROP SEQUENCE public.inventory_id_seq;
DROP TABLE public.inventory;
DROP SEQUENCE public.application_master_application_id_seq;
DROP TABLE public.application_master;
DROP SEQUENCE public."Requests_id_seq";
DROP TABLE public.requests;
DROP FUNCTION public.update_stock();
DROP FUNCTION public.add_transaction();
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: add_transaction(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION add_transaction() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
IF(NEW.request_status = true) THEN
  INSERT INTO inventory(application_id, quantity)
  VALUES(NEW.application_id, NEW.quantity);
  DELETE FROM public.requests
  WHERE id = NEW.id;
  RETURN OLD;
ELSE
	RETURN NEW;
END IF;
END;

$$;


ALTER FUNCTION public.add_transaction() OWNER TO postgres;

--
-- Name: update_stock(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_stock() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
IF(TG_OP = 'INSERT') THEN
  UPDATE application_master
  SET quantity = quantity - NEW.quantity
  WHERE application_id = NEW.application_id;
  RETURN NEW;
ELSIF(TG_OP = 'DELETE') THEN
  UPDATE application_master
  SET quantity = quantity + OLD.quantity
  WHERE application_id = OLD.application_id;
  RETURN OLD;
ELSIF(TG_OP = 'UPDATE') THEN
  UPDATE application_master
  SET quantity = quantity - NEW.quantity + OLD.quantity
  WHERE application_id = OLD.application_id;
  RETURN NEW;
END IF;
END;
$$;


ALTER FUNCTION public.update_stock() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE requests (
    id bigint NOT NULL,
    quantity bigint,
    request_status boolean DEFAULT false,
    application_id bigint,
    user_id integer
);


ALTER TABLE requests OWNER TO postgres;

--
-- Name: Requests_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "Requests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "Requests_id_seq" OWNER TO postgres;

--
-- Name: Requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "Requests_id_seq" OWNED BY requests.id;


--
-- Name: application_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE application_master (
    application_id bigint NOT NULL,
    application_name character varying(250) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_by numeric(5,0) NOT NULL,
    creation_date timestamp without time zone DEFAULT now() NOT NULL,
    modified_by numeric(5,0),
    modified_date timestamp without time zone,
    description character varying(254),
    quantity bigint DEFAULT 0,
    item_type bigint
);


ALTER TABLE application_master OWNER TO postgres;

--
-- Name: TABLE application_master; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE application_master IS 'Application Master';


--
-- Name: application_master_application_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE application_master_application_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE application_master_application_id_seq OWNER TO postgres;

--
-- Name: application_master_application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE application_master_application_id_seq OWNED BY application_master.application_id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventory (
    quantity bigint,
    transaction_date timestamp without time zone DEFAULT now(),
    id bigint NOT NULL,
    application_id bigint
);


ALTER TABLE inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inventory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inventory_id_seq OWNED BY inventory.id;


--
-- Name: item_type_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE item_type_master (
    item_type_id bigint NOT NULL,
    item_type_desc character varying(250)
);


ALTER TABLE item_type_master OWNER TO postgres;

--
-- Name: link_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE link_master (
    id integer NOT NULL,
    link_url character varying,
    link_name character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    created_by numeric,
    is_active boolean DEFAULT true,
    application_id bigint,
    link_description character varying(200),
    parent_link_id bigint,
    link_type bigint,
    order_id numeric(2,0)
);


ALTER TABLE link_master OWNER TO postgres;

--
-- Name: COLUMN link_master.link_description; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN link_master.link_description IS 'Link Description';


--
-- Name: COLUMN link_master.parent_link_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN link_master.parent_link_id IS 'Parent Link ';


--
-- Name: COLUMN link_master.order_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN link_master.order_id IS 'Order by ';


--
-- Name: link_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE link_master_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE link_master_id_seq OWNER TO postgres;

--
-- Name: link_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE link_master_id_seq OWNED BY link_master.id;


--
-- Name: link_type_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE link_type_master (
    id integer NOT NULL,
    "desc" character(1),
    is_active boolean
);


ALTER TABLE link_type_master OWNER TO postgres;

--
-- Name: COLUMN link_type_master."desc"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN link_type_master."desc" IS 'Link Type Description';


--
-- Name: link_type_master_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE link_type_master_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE link_type_master_id_seq OWNER TO postgres;

--
-- Name: link_type_master_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE link_type_master_id_seq OWNED BY link_type_master.id;


--
-- Name: role_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE role_master (
    role_desc character varying(250) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    created_by numeric(5,0) NOT NULL,
    creation_date timestamp without time zone DEFAULT now() NOT NULL,
    modified_by numeric(5,0),
    modified_date timestamp without time zone,
    role_id integer NOT NULL
);


ALTER TABLE role_master OWNER TO postgres;

--
-- Name: TABLE role_master; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE role_master IS 'Role Master';


--
-- Name: role_master_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE role_master_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE role_master_role_id_seq OWNER TO postgres;

--
-- Name: role_master_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE role_master_role_id_seq OWNED BY role_master.role_id;


--
-- Name: user_auth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE user_auth (
    login_id character varying(255),
    password character varying(255),
    emp_code bigint,
    created_by bigint,
    created_date timestamp without time zone,
    modified_by bigint,
    modified_date timestamp without time zone,
    from_date timestamp without time zone,
    to_date timestamp without time zone,
    is_active boolean,
    is_admin boolean,
    session_token bigint,
    org_id bigint,
    user_id integer NOT NULL,
    user_role character varying
);


ALTER TABLE user_auth OWNER TO postgres;

--
-- Name: COLUMN user_auth.org_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN user_auth.org_id IS 'Organization ID';


--
-- Name: user_auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_auth_user_id_seq OWNER TO postgres;

--
-- Name: user_auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_auth_user_id_seq OWNED BY user_auth.user_id;


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE user_role (
    auth_user_id bigint,
    role_id bigint,
    is_active boolean DEFAULT false NOT NULL,
    created_by numeric(5,0) NOT NULL,
    created_date timestamp without time zone DEFAULT now() NOT NULL,
    modified_by numeric(5,0),
    modified_date timestamp without time zone,
    role_sl_no integer NOT NULL
);


ALTER TABLE user_role OWNER TO postgres;

--
-- Name: TABLE user_role; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE user_role IS 'User mapped with role';


--
-- Name: user_role_role_sl_no_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_role_role_sl_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_role_role_sl_no_seq OWNER TO postgres;

--
-- Name: user_role_role_sl_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_role_role_sl_no_seq OWNED BY user_role.role_sl_no;


--
-- Name: application_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY application_master ALTER COLUMN application_id SET DEFAULT nextval('application_master_application_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventory ALTER COLUMN id SET DEFAULT nextval('inventory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_master ALTER COLUMN id SET DEFAULT nextval('link_master_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_type_master ALTER COLUMN id SET DEFAULT nextval('link_type_master_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requests ALTER COLUMN id SET DEFAULT nextval('"Requests_id_seq"'::regclass);


--
-- Name: role_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY role_master ALTER COLUMN role_id SET DEFAULT nextval('role_master_role_id_seq'::regclass);


--
-- Name: user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_auth ALTER COLUMN user_id SET DEFAULT nextval('user_auth_user_id_seq'::regclass);


--
-- Name: role_sl_no; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_role ALTER COLUMN role_sl_no SET DEFAULT nextval('user_role_role_sl_no_seq'::regclass);


--
-- Name: Requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"Requests_id_seq"', 16, true);


--
-- Data for Name: application_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY application_master (application_id, application_name, is_active, created_by, creation_date, modified_by, modified_date, description, quantity, item_type) FROM stdin;
\.
COPY application_master (application_id, application_name, is_active, created_by, creation_date, modified_by, modified_date, description, quantity, item_type) FROM '$$PATH$$/2233.dat';

--
-- Name: application_master_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('application_master_application_id_seq', 11, true);


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventory (quantity, transaction_date, id, application_id) FROM stdin;
\.
COPY inventory (quantity, transaction_date, id, application_id) FROM '$$PATH$$/2244.dat';

--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inventory_id_seq', 8, true);


--
-- Data for Name: item_type_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY item_type_master (item_type_id, item_type_desc) FROM stdin;
\.
COPY item_type_master (item_type_id, item_type_desc) FROM '$$PATH$$/2248.dat';

--
-- Data for Name: link_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY link_master (id, link_url, link_name, created_at, created_by, is_active, application_id, link_description, parent_link_id, link_type, order_id) FROM stdin;
\.
COPY link_master (id, link_url, link_name, created_at, created_by, is_active, application_id, link_description, parent_link_id, link_type, order_id) FROM '$$PATH$$/2237.dat';

--
-- Name: link_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('link_master_id_seq', 8, true);


--
-- Data for Name: link_type_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY link_type_master (id, "desc", is_active) FROM stdin;
\.
COPY link_type_master (id, "desc", is_active) FROM '$$PATH$$/2235.dat';

--
-- Name: link_type_master_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('link_type_master_id_seq', 1, false);


--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY requests (id, quantity, request_status, application_id, user_id) FROM stdin;
\.
COPY requests (id, quantity, request_status, application_id, user_id) FROM '$$PATH$$/2247.dat';

--
-- Data for Name: role_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY role_master (role_desc, is_active, created_by, creation_date, modified_by, modified_date, role_id) FROM stdin;
\.
COPY role_master (role_desc, is_active, created_by, creation_date, modified_by, modified_date, role_id) FROM '$$PATH$$/2239.dat';

--
-- Name: role_master_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('role_master_role_id_seq', 7, true);


--
-- Data for Name: user_auth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_auth (login_id, password, emp_code, created_by, created_date, modified_by, modified_date, from_date, to_date, is_active, is_admin, session_token, org_id, user_id, user_role) FROM stdin;
\.
COPY user_auth (login_id, password, emp_code, created_by, created_date, modified_by, modified_date, from_date, to_date, is_active, is_admin, session_token, org_id, user_id, user_role) FROM '$$PATH$$/2241.dat';

--
-- Name: user_auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_auth_user_id_seq', 24, true);


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_role (auth_user_id, role_id, is_active, created_by, created_date, modified_by, modified_date, role_sl_no) FROM stdin;
\.
COPY user_role (auth_user_id, role_id, is_active, created_by, created_date, modified_by, modified_date, role_sl_no) FROM '$$PATH$$/2243.dat';

--
-- Name: user_role_role_sl_no_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_role_role_sl_no_seq', 13, true);


--
-- Name: Requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requests
    ADD CONSTRAINT "Requests_pkey" PRIMARY KEY (id);


--
-- Name: adm_application_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY application_master
    ADD CONSTRAINT adm_application_pkey PRIMARY KEY (application_id);


--
-- Name: application_master_application_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY application_master
    ADD CONSTRAINT application_master_application_name_key UNIQUE (application_name);


--
-- Name: emp_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT emp_role_pkey PRIMARY KEY (role_sl_no);


--
-- Name: inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: item_type_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item_type_master
    ADD CONSTRAINT item_type_master_pkey PRIMARY KEY (item_type_id);


--
-- Name: link_mast_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_master
    ADD CONSTRAINT link_mast_pkey PRIMARY KEY (id);


--
-- Name: link_type_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_type_master
    ADD CONSTRAINT link_type_master_pkey PRIMARY KEY (id);


--
-- Name: role_master_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY role_master
    ADD CONSTRAINT role_master_pkey PRIMARY KEY (role_id);


--
-- Name: user_auth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_auth
    ADD CONSTRAINT user_auth_pkey PRIMARY KEY (user_id);


--
-- Name: add_transaction; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER add_transaction AFTER UPDATE OF request_status ON requests FOR EACH ROW EXECUTE PROCEDURE add_transaction();


--
-- Name: stock_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER stock_update AFTER INSERT OR DELETE OR UPDATE ON inventory FOR EACH ROW EXECUTE PROCEDURE update_stock();


--
-- Name: application_master_item_type_master_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY application_master
    ADD CONSTRAINT application_master_item_type_master_fkey FOREIGN KEY (item_type) REFERENCES item_type_master(item_type_id) MATCH FULL;


--
-- Name: inventory_application_master_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventory
    ADD CONSTRAINT inventory_application_master_fkey FOREIGN KEY (application_id) REFERENCES application_master(application_id) MATCH FULL;


--
-- Name: link_master_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_master
    ADD CONSTRAINT link_master_application_id_fkey FOREIGN KEY (application_id) REFERENCES application_master(application_id) MATCH FULL;


--
-- Name: link_master_link_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_master
    ADD CONSTRAINT link_master_link_type_fkey FOREIGN KEY (link_type) REFERENCES link_type_master(id) MATCH FULL;


--
-- Name: link_master_parent_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY link_master
    ADD CONSTRAINT link_master_parent_link_id_fkey FOREIGN KEY (parent_link_id) REFERENCES link_master(id) MATCH FULL;


--
-- Name: requests_application_master_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requests
    ADD CONSTRAINT requests_application_master_fkey FOREIGN KEY (application_id) REFERENCES application_master(application_id);


--
-- Name: requests_user_auth_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY requests
    ADD CONSTRAINT requests_user_auth_fkey FOREIGN KEY (user_id) REFERENCES user_auth(user_id) MATCH FULL;


--
-- Name: user_role_auth_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_auth_user_id_fkey FOREIGN KEY (auth_user_id) REFERENCES user_auth(user_id) MATCH FULL;


--
-- Name: user_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_role
    ADD CONSTRAINT user_role_role_id_fkey FOREIGN KEY (role_id) REFERENCES role_master(role_id) MATCH FULL;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

